package org.example.chapter06.controller;

import org.example.chapter06.entity.ClassInfo;
import org.example.chapter06.service.ClassInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("class")
public class ClassInfoController {
    @Autowired
    private ClassInfoService classInfoService;

    // 班级信息管理
    @RequestMapping("manage")
    public String findManagList(Model model) {
        model.addAttribute("classes", classInfoService.getAllClasses());
        return "class_manage";
    }

    // 添加班级信息页面
    @GetMapping("add")
    public String addClassPage(Model model) {
        model.addAttribute("classInfo", new ClassInfo());
        return "class_add";
    }

    // 添加班级信息
    @PostMapping("add")
    public String addClass(@ModelAttribute("classInfo") ClassInfo classInfo, Model model) {
        classInfoService.addClass(classInfo);
        return "redirect:/class/manage";
    }

    // 删除班级信息
    @GetMapping("delete/{id}")
    public String deleteClass(@PathVariable Integer id) {
        classInfoService.deleteClass(id);
        return "redirect:/class/manage";
    }

    // 查看班级具体信息
    @GetMapping("view/{id}")
    public String viewClass(@PathVariable Integer id, Model model) {
        Optional<ClassInfo> classInfo = classInfoService.getClassById(id);
        if (classInfo.isPresent()) {
            model.addAttribute("classInfo", classInfo.get());
            return "class_view";
        }
        return "redirect:/class/manage";
    }

    // 修改班级信息页面
    @GetMapping("editPage/{id}")
    public String editClassPage(@PathVariable Integer id, Model model) {
        Optional<ClassInfo> classInfo = classInfoService.getClassById(id);
        if (classInfo.isPresent()) {
            model.addAttribute("classInfo", classInfo.get());
            return "class_edit";
        }
        return "redirect:/class/manage";
    }

    // 修改班级信息
    @PostMapping("edit")
    public String editClass(@ModelAttribute("classInfo") ClassInfo classInfo, Model model) {
        classInfoService.updateClass(classInfo);
        return "redirect:/class/manage";
    }
}