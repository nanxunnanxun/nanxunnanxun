package org.example.chapter06.controller;

import org.example.chapter06.entity.Course;
import org.example.chapter06.entity.Teacher;
import org.example.chapter06.service.CourseService;
import org.example.chapter06.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/course")
public class CourseController {

    @Autowired
    private CourseService courseService;
    @Autowired
    private TeacherService teacherService;

    @GetMapping("/manage")
    public String manageCourses(Model model) {
        List<Course> courses = courseService.getAllCourses();
        model.addAttribute("courses", courses);
        return "course_manage";
    }

    @GetMapping("/add")
    public String addCourseForm(Model model) {
        model.addAttribute("course", new Course());
        // 这里需要添加教师列表
        List<Teacher> teachers = teacherService.getAllTeachers();
        model.addAttribute("teachers", teachers);
        return "course_add";
    }

    @PostMapping("/add")
    public String addCourse(@ModelAttribute Course course) {
        try {
            courseService.addCourse(course);
            return "redirect:/course/manage";
        } catch (Exception e) {
            e.printStackTrace();
            return "error"; // 可以创建一个 error.html 页面来显示错误信息
        }
    }

    @GetMapping("/edit/{id}")
    public String editCourseForm(@PathVariable Integer id, Model model) {
        Course course = courseService.getCourseById(id).orElseThrow(() -> new IllegalArgumentException("无效课程ID"));
        model.addAttribute("course", course);
        // 这里需要添加教师列表
        List<Teacher> teachers = teacherService.getAllTeachers();
        model.addAttribute("teachers", teachers);
        return "course_edit";
    }

    @PostMapping("/edit")
    public String editCourse(@ModelAttribute Course course) {
        try {
            courseService.updateCourse(course);
            return "redirect:/course/manage";
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }

    @GetMapping("/delete/{id}")
    public String deleteCourse(@PathVariable Integer id) {
        try {
            courseService.deleteCourse(id);
            return "redirect:/course/manage";
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }
}