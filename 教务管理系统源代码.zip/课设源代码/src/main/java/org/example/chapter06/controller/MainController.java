package org.example.chapter06.controller;

import org.example.chapter06.service.ClassInfoService;
import org.example.chapter06.service.CourseService;
import org.example.chapter06.service.StudentService;
import org.example.chapter06.service.TeacherService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    private final StudentService studentService;
    private final CourseService courseService;
    private final TeacherService teacherService;
    private final ClassInfoService classService;

    public MainController(StudentService studentService, CourseService courseService, TeacherService teacherService, ClassInfoService classService) {
        this.studentService = studentService;
        this.courseService = courseService;
        this.teacherService = teacherService;
        this.classService = classService;
    }

    @GetMapping("/")
    public String mainPage(Model model) {
        long studentCount = studentService.getStudentCount();
        System.out.println("后端获取的学生总数：" + studentCount);
        long courseCount = courseService.getCourseCount();
        long teacherCount = teacherService.getTeacherCount();
        long classCount = classService.getClassCount();

        model.addAttribute("studentCount", studentService.getStudentCount()); // 确保此值非固定1245
        model.addAttribute("courseCount", courseService.getCourseCount()); // 补充后端逻辑
        model.addAttribute("teacherCount", teacherService.getTeacherCount());
        model.addAttribute("classCount", classService.getClassCount());

        return "main";
    }
}