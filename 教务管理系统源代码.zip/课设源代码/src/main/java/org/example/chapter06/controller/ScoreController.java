package org.example.chapter06.controller;
import org.example.chapter06.entity.Course;
import org.example.chapter06.entity.Score;
import org.example.chapter06.entity.Student;
import org.example.chapter06.service.CourseService;
import org.example.chapter06.service.ScoreService;
import org.example.chapter06.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/score")
public class ScoreController {

    @Autowired
    private ScoreService scoreService;
    @Autowired
    private StudentService studentService;
    @Autowired
    private CourseService courseService;

    @GetMapping("/manage")
    public String manageScores(Model model) {
        List<Score> scores = scoreService.getAllScores();
        model.addAttribute("scores", scores);
        return "score_manage";
    }

    @GetMapping("/add")
    public String addScoreForm(Model model) {
        model.addAttribute("score", new Score());
        // 这里需要添加学生列表和课程列表
        List<Student> students = studentService.getAllStudents();
        List<Course> courses = courseService.getAllCourses();
        model.addAttribute("students", students);
        model.addAttribute("courses", courses);
        return "score_add";
    }

    @PostMapping("/add")
    public String addScore(@ModelAttribute Score score) {
        try {
            scoreService.addScore(score);
            return "redirect:/score/manage";
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }

    @GetMapping("/edit/{id}")
    public String editScoreForm(@PathVariable Integer id, Model model) {
        Score score = scoreService.getScoreById(id).orElseThrow(() -> new IllegalArgumentException("无效成绩ID"));
        model.addAttribute("score", score);
        // 这里需要添加学生列表和课程列表
        List<Student> students = studentService.getAllStudents();
        List<Course> courses = courseService.getAllCourses();
        model.addAttribute("students", students);
        model.addAttribute("courses", courses);
        return "score_edit";
    }

    @PostMapping("/edit")
    public String editScore(@ModelAttribute Score score) {
        try {
            scoreService.updateScore(score);
            return "redirect:/score/manage";
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }

    @GetMapping("/delete/{id}")
    public String deleteScore(@PathVariable Integer id) {
        try {
            scoreService.deleteScore(id);
            return "redirect:/score/manage";
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }
}