package org.example.chapter06.controller;

import org.example.chapter06.entity.Student;
import org.example.chapter06.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("student")
public class StudentController {
    @Autowired
    private StudentService studentService;

    // 学生信息管理
    @RequestMapping("admin/manag")
    public String findManageList(Model model) {
        model.addAttribute("students", studentService.getAllStudents());
        return "student_manage";
    }

    // 添加学生信息页面
    @GetMapping("add")
    public String addStudentPage(Model model) {
        // 创建一个空的 Student 对象并添加到模型中
        model.addAttribute("student", new Student());
        return "student_add";
    }

    // 添加学生信息
    @PostMapping("add")
    public String addStudent(@ModelAttribute("student") Student student, Model model) {
        studentService.addStudent(student);
        return "redirect:/student/admin/manag"; // 修改重定向路径
    }

    // 删除学生信息
    @GetMapping("delete/{id}")
    public String deleteStudent(@PathVariable Integer id) {
        studentService.deleteStudent(id);
        return "redirect:/student/admin/manag";
    }

    // 查看学生具体信息
    @GetMapping("view/{id}")
    public String viewStudent(@PathVariable Integer id, Model model) {
        Optional<Student> student = studentService.getStudentById(id);
        if (student.isPresent()) {
            model.addAttribute("student", student.get());
            return "student_view";
        }
        return "redirect:/student/admin/manag";
    }
    // 修改学生信息页面
    @GetMapping("editPage/{id}")
    public String editStudentPage(@PathVariable Integer id, Model model) {
        Optional<Student> student = studentService.getStudentById(id);
        if (student.isPresent()) {
            model.addAttribute("student", student.get());
            return "student_edit";
        }
        return "redirect:/student/admin/manag";
    }

    // 修改学生信息
    @PostMapping("edit")
    public String editStudent(@ModelAttribute("student") Student student, Model model) {
        studentService.addStudent(student); // 由于 JPA 的 save 方法可以用于保存和更新，这里直接调用 addStudent 方法
        return "redirect:/student/admin/manag";
    }
    @GetMapping("manage")
    public String manageStudent(Model model) {
       List<Student> students = studentService.getAllStudents();
       model.addAttribute("students", students);
        return "student_manage"; // 返回学生信息管理页面的视图名称
    }
}