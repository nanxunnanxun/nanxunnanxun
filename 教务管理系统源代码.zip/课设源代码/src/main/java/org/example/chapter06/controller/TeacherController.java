// chapter06/src/main/java/org/example/chapter06/controller/TeacherController.java
package org.example.chapter06.controller;

import org.example.chapter06.entity.Teacher;
import org.example.chapter06.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/teacher")
public class TeacherController {

    @Autowired
    private TeacherService teacherService;

    @GetMapping("/manage")
    public String manageTeachers(Model model) {
        List<Teacher> teachers = teacherService.getAllTeachers();
        model.addAttribute("teachers", teachers);
        return "teacher_manage";
    }

    @GetMapping("/add")
    public String addTeacherForm(Model model) {
        model.addAttribute("teacher", new Teacher());
        return "teacher_add";
    }

    @PostMapping("/add")
    public String addTeacher(@ModelAttribute Teacher teacher, Model model) {
        // 确保 teacherId 有值
        if (teacher.getTeacherId() == null) {
            // 可以根据实际情况设置默认值或者抛出异常
            throw new IllegalArgumentException("teacherId 不能为空");
        }
        teacherService.addTeacher(teacher);
        return "redirect:/teacher/manage";
    }

    @GetMapping("/edit/{id}")
    public String editTeacherForm(@PathVariable Integer id, Model model) {
        Teacher teacher = teacherService.getTeacherById(id).orElseThrow(() -> new IllegalArgumentException("无效教师ID"));
        model.addAttribute("teacher", teacher);
        return "teacher_edit";
    }

    @PostMapping("/edit")
    public String editTeacher(@ModelAttribute Teacher teacher) {
        try {
            teacherService.updateTeacher(teacher);
            return "redirect:/teacher/manage";
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }

    @GetMapping("/delete/{id}")
    public String deleteTeacher(@PathVariable Integer id) {
        try {
            teacherService.deleteTeacher(id);
            return "redirect:/teacher/manage";
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }
}