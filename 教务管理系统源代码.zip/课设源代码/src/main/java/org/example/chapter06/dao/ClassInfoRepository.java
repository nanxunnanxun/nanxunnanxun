package org.example.chapter06.dao;

import org.example.chapter06.entity.ClassInfo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClassInfoRepository extends JpaRepository<ClassInfo, Integer> {
}