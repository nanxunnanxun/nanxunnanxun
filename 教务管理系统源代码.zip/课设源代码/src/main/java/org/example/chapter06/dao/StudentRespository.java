package org.example.chapter06.dao;

import org.example.chapter06.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRespository extends JpaRepository<Student, Integer> {
    // 自定义方法
}