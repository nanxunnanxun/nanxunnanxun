// chapter06/src/main/java/org/example/chapter06/repository/TeacherRepository.java
package org.example.chapter06.dao;

import org.example.chapter06.entity.Teacher;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TeacherRepository extends JpaRepository<Teacher, Integer> {
}