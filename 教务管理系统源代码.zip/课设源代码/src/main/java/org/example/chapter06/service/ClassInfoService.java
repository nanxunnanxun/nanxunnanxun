package org.example.chapter06.service;

import org.example.chapter06.entity.ClassInfo;
import java.util.List;
import java.util.Optional;

public interface ClassInfoService {
    List<ClassInfo> getAllClasses();
    void addClass(ClassInfo classInfo);
    void deleteClass(Integer id);
    Optional<ClassInfo> getClassById(Integer id);
    void updateClass(ClassInfo classInfo);
    long getClassCount();

}