package org.example.chapter06.service;

import org.example.chapter06.entity.Course;

import java.util.List;
import java.util.Optional;

public interface CourseService {
    List<Course> getAllCourses();
    Course addCourse(Course course);
    Course updateCourse(Course course);
    void deleteCourse(Integer id);
    Optional<Course> getCourseById(Integer id);
    long getCourseCount();
}