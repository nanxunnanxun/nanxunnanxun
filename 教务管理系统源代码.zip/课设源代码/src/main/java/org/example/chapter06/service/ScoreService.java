package org.example.chapter06.service;

import org.example.chapter06.entity.Score;

import java.util.List;
import java.util.Optional;

public interface ScoreService {
    List<Score> getAllScores();
    Score addScore(Score score);
    Score updateScore(Score score);
    void deleteScore(Integer id);
    Optional<Score> getScoreById(Integer id);
}