// chapter06/src/main/java/org/example/chapter06/service/TeacherService.java
package org.example.chapter06.service;

import org.example.chapter06.entity.Teacher;

import java.util.List;
import java.util.Optional;

public interface TeacherService {
    List<Teacher> getAllTeachers();
    Optional<Teacher> getTeacherById(Integer id);
    Teacher addTeacher(Teacher teacher);
    Teacher updateTeacher(Teacher teacher);
    void deleteTeacher(Integer id);
    long getTeacherCount();
}