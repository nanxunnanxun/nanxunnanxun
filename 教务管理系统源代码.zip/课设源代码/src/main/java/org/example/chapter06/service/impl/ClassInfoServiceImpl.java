package org.example.chapter06.service.impl;

import org.example.chapter06.entity.ClassInfo;
import org.example.chapter06.dao.ClassInfoRepository;
import org.example.chapter06.service.ClassInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ClassInfoServiceImpl implements ClassInfoService {
    @Autowired
    private ClassInfoRepository classInfoRepository;

    @Override
    public List<ClassInfo> getAllClasses() {
        return classInfoRepository.findAll();
    }

    @Override
    public void addClass(ClassInfo classInfo) {
        classInfoRepository.save(classInfo);
    }

    @Override
    public void deleteClass(Integer id) {
        classInfoRepository.deleteById(id);
    }

    @Override
    public Optional<ClassInfo> getClassById(Integer id) {
        return classInfoRepository.findById(id);
    }

    @Override
    public void updateClass(ClassInfo classInfo) {
        classInfoRepository.save(classInfo);
    }
    public long getClassCount() {
        return classInfoRepository.count();
    }
}