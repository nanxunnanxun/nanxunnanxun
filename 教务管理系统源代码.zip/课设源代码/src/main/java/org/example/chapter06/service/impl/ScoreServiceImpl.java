package org.example.chapter06.service.impl;

import org.example.chapter06.entity.Score;
import org.example.chapter06.dao.ScoreRepository;
import org.example.chapter06.service.ScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ScoreServiceImpl implements ScoreService {

    @Autowired
    private ScoreRepository scoreRepository;

    @Override
    public List<Score> getAllScores() {
        return scoreRepository.findAll();
    }

    @Override
    public Score addScore(Score score) {
        return scoreRepository.save(score);
    }

    @Override
    public Score updateScore(Score score) {
        return scoreRepository.save(score);
    }

    @Override
    public void deleteScore(Integer id) {
        scoreRepository.deleteById(id);
    }

    @Override
    public Optional<Score> getScoreById(Integer id) {
        return scoreRepository.findById(id);
    }
}