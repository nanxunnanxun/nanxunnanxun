package org.example.chapter07.config;


import  org.springframework.context.annotation.Bean;
import  org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import  org.springframework.security.config.annotation.web.builders.HttpSecurity;
import  org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import  org.springframework.security.crypto.password.PasswordEncoder;
import  org.springframework.security.web.SecurityFilterChain;
@Configuration
@EnableGlobalMethodSecurity(securedEnabled = true ,prePostEnabled = true )
public  class  WebSecurityConfig {
    @Bean
    public  PasswordEncoder passwordEncoder() {
        return  new  BCryptPasswordEncoder();
    }
    @Bean
    public  SecurityFilterChain securityFilterChain(HttpSecurity http) throws  Exception{
        http.authorizeRequests() // 定义哪些URL需要被保护、哪些不需要被保护
                .mvcMatchers("/loginview","/css/**","/img/**").permitAll()
                .mvcMatchers("/book/admin/**").hasRole("ADMIN")
                .anyRequest().authenticated() // 任何请求,登录后可以访问
                .and()
                .formLogin()
                .loginPage("/loginview")
                .loginProcessingUrl("/doLogin")
                .and()
                .csrf().disable()//禁止csrf 跨站请求保护;
                .headers().frameOptions().sameOrigin();
        return  http.build();
    }
}
