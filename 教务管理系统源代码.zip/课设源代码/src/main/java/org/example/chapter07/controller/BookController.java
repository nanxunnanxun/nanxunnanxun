package org.example.chapter07.controller;

import  org.springframework.security.access.annotation.Secured;
import  org.springframework.security.access.prepost.PreAuthorize;
import  org.springframework.stereotype.Controller;
import  org.springframework.web.bind.annotation.RequestMapping;

import  javax.annotation.security.RolesAllowed;

@Controller
@RequestMapping("book")

public  class  BookController {
    @RequestMapping("list")
    public  String findList() {
        return  "book_list";
    }
    @RequestMapping("admin/manag")
    @Secured("ROLE_ADMIN")
    public  String findManagList() {
        return  "book_manag";
    }
}

