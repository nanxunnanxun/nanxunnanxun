document.addEventListener('DOMContentLoaded', function() {
    // 模拟数据加载
    loadDashboardData();

    // 初始化图表
    initCharts();

    // 添加导航栏交互效果
    initSidebar();

    // 模拟加载最近添加的学生
    loadRecentStudents();

    // 模拟加载系统公告
    loadAnnouncements();
});

// 加载仪表盘数据
function loadDashboardData() {
    // 直接使用Thymeleaf渲染的数值，无需模拟数据
    const studentCount = document.getElementById('studentCount').textContent;
    const courseCount = document.getElementById('courseCount').textContent;
    const teacherCount = document.getElementById('teacherCount').textContent;
    const classCount = document.getElementById('classCount').textContent;

    // 如需格式化数字（如添加逗号），可转换为数字后处理：
    // document.getElementById('studentCount').textContent =
    //   parseInt(studentCount).toLocaleString();

    // 直接显示后端数据
    document.getElementById('studentCount').textContent = studentCount;
    document.getElementById('courseCount').textContent = courseCount;
    document.getElementById('teacherCount').textContent = teacherCount;
    document.getElementById('classCount').textContent = classCount;
}
// 初始化图表
function initCharts() {
    // 模拟数据
    const data = {
        labels: ['一月', '二月', '三月', '四月', '五月', '六月'],
        datasets: [{
            label: '学生注册数',
            data: [65, 78, 90, 81, 106, 125],
            borderColor: '#3c8dbc',
            backgroundColor: 'rgba(60, 141, 188, 0.1)',
            tension: 0.4,
            fill: true
        }]
    };

    // 配置选项
    const config = {
        type: 'line',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    };

    // 创建图表
    const ctx = document.getElementById('studentChart');
    if (ctx) {
        new Chart(ctx, config);
    }
}

// 初始化侧边栏交互
function initSidebar() {
    const sidebarItems = document.querySelectorAll('.sidebar-menu li');

    sidebarItems.forEach(item => {
        item.addEventListener('click', function() {
            // 移除所有项的活动状态
            sidebarItems.forEach(li => li.classList.remove('active'));

            // 添加当前项的活动状态
            this.classList.add('active');
        });
    });
}

// 加载最近添加的学生
function loadRecentStudents() {
    const container = document.getElementById('recentStudents');

    // 模拟API返回的数据
    const students = [
        { id: 1001, name: '张三', gender: '男', major: '计算机科学', avatar: 'https://picsum.photos/id/1005/50/50' },
        { id: 1002, name: '李四', gender: '女', major: '电子工程', avatar: 'https://picsum.photos/id/1006/50/50' },
        { id: 1003, name: '王五', gender: '男', major: '机械工程', avatar: 'https://picsum.photos/id/1012/50/50' },
        { id: 1004, name: '赵六', gender: '女', major: '会计学', avatar: 'https://picsum.photos/id/1027/50/50' }
    ];

    // 清空容器
    container.innerHTML = '';

    // 添加学生数据
    students.forEach(student => {
        const item = document.createElement('li');
        item.className = 'item';
        item.innerHTML = `
            <div class="product-img">
                <img src="${student.avatar}" alt="Student Image">
            </div>
            <div class="product-info">
                <a href="javascript:void(0)" class="product-title">${student.name}
                    <span class="label label-info pull-right">${student.gender}</span></a>
                <span class="product-description">
                    ${student.major}
                </span>
            </div>
        `;
        container.appendChild(item);
    });
}

// 加载系统公告
function loadAnnouncements() {
    const container = document.getElementById('announcements');

    // 模拟API返回的数据
    const announcements = [
        { id: 1, title: '系统升级通知', content: '系统将于本周日凌晨2点至5点进行升级维护，请提前做好准备。', date: '2023-06-10', icon: 'fa-bullhorn' },
        { id: 2, title: '新学期注册通知', content: '新学期学生注册工作将于9月1日开始，请同学们及时完成注册。', date: '2023-08-25', icon: 'fa-calendar' },
        { id: 3, title: '奖学金申请通知', content: '2023年度奖学金申请工作现已开始，截止日期为10月15日。', date: '2023-09-05', icon: 'fa-trophy' }
    ];

    // 清空容器
    container.innerHTML = '';

    // 添加公告数据
    announcements.forEach(ann => {
        const item = document.createElement('li');
        item.innerHTML = `
            <i class="fa ${ann.icon} bg-blue"></i>
            <div class="timeline-item">
                <span class="time"><i class="fa fa-clock-o"></i> ${ann.date}</span>
                <h3 class="timeline-header">${ann.title}</h3>
                <div class="timeline-body">
                    ${ann.content}
                </div>
            </div>
        `;
        container.appendChild(item);
    });

    // 添加一个"现在"的时间点
    const nowItem = document.createElement('li');
    nowItem.innerHTML = `
        <i class="fa fa-clock-o bg-gray"></i>
    `;
    container.appendChild(nowItem);
}

// 为按钮添加动画效果
document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
        const x = e.clientX - e.target.getBoundingClientRect().left;
        const y = e.clientY - e.target.getBoundingClientRect().top;

        const ripple = document.createElement('span');
        ripple.style.left = `${x}px`;
        ripple.style.top = `${y}px`;
        ripple.classList.add('ripple');

        this.appendChild(ripple);

        setTimeout(() => {
            ripple.remove();
        }, 600);
    });
});

// 添加涟漪效果的CSS
const style = document.createElement('style');
style.textContent = `
    .ripple {
        position: absolute;
        border-radius: 50%;
        background-color: rgba(255, 255, 255, 0.7);
        transform: scale(0);
        animation: ripple 0.6s linear;
        pointer-events: none;
    }
    
    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
// 页面加载完成后执行
$(document).ready(function() {
    // 为删除按钮添加确认提示
    $('.btn-danger').click(function() {
        return confirm('确定要删除该记录吗？');
    });
});