package org.example.chapter06;

/*import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@Nested
@SpringBootTest
public class Chapter06ApplicationMPTests {
    @Autowired
    private StudentMapper studentMapper;
    @Autowired
    private StudentService studentService;
    @Test
    void studentInfo(){
        List<EStudent>eStudents = studentMapper.selectList(null);
        for(EStudent eStudent : eStudents){
            System.out.println(eStudent);
        }
        }
    @Test
    void saveStudent(){
        EStudent eStudent = new EStudent(null,"白云飞","软件工程","202252340208","2");
        studentMapper.insert(eStudent);
        studentInfo();
    }
    @Test
    void findStudent(){
        QueryWrapper<EStudent> wrapper = new QueryWrapper<>();
        wrapper.eq("status","1").like("major","工");
        List<EStudent> estudents = studentMapper.selectList(wrapper);
        for(EStudent eStudent : estudents){
            System.out.println(eStudent);
        }
    }
    @Test
    void editStudent(){
        System.out.println("----------学生信息修改前--------");
        studentInfo();
        EStudent eStudent = studentService.getById(16);
        eStudent.setId(5);
        eStudent.setName("白云飞");
        eStudent.setMajor("软件工程");
        eStudent.setStudentId("202252340208");
        eStudent.setStatus("0");

        studentMapper.updateById(eStudent);
        System.out.println("----------学生信息修改后--------");
        studentInfo();
    }
    @Test
    void deleteStudent(){
        studentService.removeById(16);
        studentInfo();
    }
}*/

