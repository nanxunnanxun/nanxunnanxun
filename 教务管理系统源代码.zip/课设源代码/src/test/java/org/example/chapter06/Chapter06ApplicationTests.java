/*package org.example.chapter06;


import org.example.chapter06.dao.StudentRepository;
import org.example.chapter06.entity.Student;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Optional;

@SpringBootTest
class StudentManagementApplicationTests {

    @Autowired
    private StudentRepository studentRepository;
    private void studentsInfo() {
        List<Student> students = studentRepository.findAll();
        for (Student student : students) {
            System.out.println(student);
        }
    }

    @Test
        void saveStudent() {Student student = new Student(null, "张三", "计算机科学", "2025001", "1");
        studentRepository.save(student);
        studentsInfo();
    }

    @Test
    void editStudent() {
        Optional<Student> op = studentRepository.findById(1);
        Student student = op.get();
        student.setName("李四");
        student.setMajor("软件工程");
        studentRepository.save(student);
        studentsInfo();
    }

    @Test
    void findStudent() {
        Student s = studentRepository.findByStudentIdAndStatus(("2025001"),"1");
        System.out.println(s);
    }

    @Test
    void deleteStudent() {
        studentRepository.deleteById(1);
        studentsInfo();
    }
}    */